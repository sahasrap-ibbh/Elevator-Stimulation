
ravi11#include <Wire.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

int buttons[] = {2, 3, 4, 5};
int leds[] = {8, 9, 10, 11};

int currentFloor = 0;
int targetFloor = -1;

void setup() {
  lcd.init();
  lcd.backlight();

  for (int i = 0; i < 4; i++) {
    pinMode(buttons[i], INPUT_PULLUP);
    pinMode(leds[i], OUTPUT);
    digitalWrite(leds[i], LOW);
  }

  digitalWrite(leds[currentFloor], HIGH);

  lcd.setCursor(0, 0);
  lcd.print("Floor: 1");
}

void loop() {

  // Read buttons
  for (int i = 0; i < 4; i++) {
    if (digitalRead(buttons[i]) == LOW) {
      targetFloor = i;
      delay(200); // debounce
    }
  }

  // Move elevator
  if (targetFloor != -1 && targetFloor != currentFloor) {
    moveLift(targetFloor);
    targetFloor = -1;
  }
}

void moveLift(int target) {

  while (currentFloor != target) {

    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Moving...");

    digitalWrite(leds[currentFloor], LOW);

    if (currentFloor < target) {
      currentFloor++;
    } else {
      currentFloor--;
    }

    digitalWrite(leds[currentFloor], HIGH);

    lcd.setCursor(0, 1);
    lcd.print("Floor: ");
    lcd.print(currentFloor + 1);

    delay(1000);
  }

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Reached Floor");
  lcd.setCursor(0, 1);
  lcd.print(currentFloor + 1);

  delay(1500);
}